document.getElementById("submitBtn").addEventListener("click", async () => {
  const slug = document.getElementById("slug").value.trim();
  const code = document.getElementById("code").value;
  const statusEl = document.getElementById("status");
  const btn = document.getElementById("submitBtn");

  if (!slug || !code) {
    showStatus("Please provide both slug and code.", "error");
    return;
  }

  btn.disabled = true;
  showStatus("Opening LeetCode & Injecting Code...", "info");

  chrome.runtime.sendMessage(
    { type: "SUBMIT_FROM_POPUP", slug, code },
    (response) => {
      btn.disabled = false;
      if (chrome.runtime.lastError) {
        showStatus("Error: " + chrome.runtime.lastError.message, "error");
        return;
      }

      if (response && response.success) {
        const v = response.verdict;
        showStatus(`Verdict: ${v.verdict} (${v.details || ""})`, "success");
      } else {
        showStatus("Submission Failed: " + (response?.error || "Unknown"), "error");
      }
    }
  );
});

function showStatus(text, type) {
  const el = document.getElementById("status");
  el.style.display = "block";
  el.className = type;
  el.innerText = text;
}