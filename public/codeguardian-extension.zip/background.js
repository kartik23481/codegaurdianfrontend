// chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
//   if (request.type === "SUBMIT_SOLUTION") {
//     // Pass the screenMeta payload down to the handler
//     handleSubmission(request.slug, request.code, request.screenMeta)
//       .then((verdict) => sendResponse({ success: true, verdict }))
//       .catch((err) => sendResponse({ success: false, error: err.message }));
//     return true; // Keep message channel open for async response
//   }
// });

// Auto-inject relay.js into already open CodeGuardian tabs upon installation
chrome.runtime.onInstalled.addListener(async () => {
  const tabs = await chrome.tabs.query({}); // Get all open tabs

  for (const tab of tabs) {
    // Check if the tab is our CodeGuardian frontend
    if (tab.url && (tab.url.includes("localhost:3000") || tab.url.includes("vercel.app"))) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["relay.js"]
        });
        console.log(`✅ Dynamically injected relay bridge into CodeGuardian tab: ${tab.id}`);
      } catch (err) {
        console.warn(`⚠️ Could not inject into tab ${tab.id}:`, err);
      }
    }
  }
});

// CRITICAL FIX: Update internal listener to catch "SUBMIT_SOLUTION" from relay.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "SUBMIT_SOLUTION" || request.type === "SUBMIT_FROM_POPUP") {
    handleSubmission(request.slug, request.code, request.screenMeta)
      .then((verdict) => sendResponse({ success: true, verdict }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // Keep message channel open for async response
  }
});

async function handleSubmission(slug, code, screenMeta) {
  const targetUrl = `https://leetcode.com/problems/${slug}/`;

  // Calculate the exact center of the user's monitor
  const popupWidth = 1100;
  const popupHeight = 750;
  let left = 100;
  let top = 100;

  if (screenMeta) {
    left = Math.round(screenMeta.left + (screenMeta.width / 2) - (popupWidth / 2));
    top = Math.round(screenMeta.top + (screenMeta.height / 2) - (popupHeight / 2));
  }

  // 1. Create a centered, frameless popup window
  const newWindow = await chrome.windows.create({
    url: targetUrl,
    type: "popup", // Disables the URL bar and tab strip for a clean app feel
    width: popupWidth,
    height: popupHeight,
    left: left,
    top: top,
    focused: true
  });

  const tabId = newWindow.tabs[0].id;

  // 2. Wait for the new window's tab to complete loading
  await new Promise((resolve) => {
    const listener = (tId, info) => {
      if (tId === tabId && info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });

  // 3. Inject execution script into the MAIN world (where window.monaco is accessible)
  const results = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: "MAIN",
    func: executeLeetCodeFlow,
    args: [code]
  });

  const finalVerdict = results[0]?.result;

  // 4. Leave window open as requested by user
  // (Window remains until user explicitly closes it)

  return finalVerdict;
}

// Injected directly into the LeetCode web page
async function executeLeetCodeFlow(solutionCode) {
  const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

  console.log("🚀 Starting LeetCode Automation...");
  console.log(`📋 Code to inject (first 100 chars): ${solutionCode.substring(0, 100)}...`);

  // STEP 1: Wait for Monaco Editor DOM to appear (up to 20 seconds)
  let editorDom = null;
  for (let i = 0; i < 40; i++) {
    editorDom = document.querySelector(".monaco-editor");
    if (editorDom) break;
    await sleep(500);
  }
  if (!editorDom) throw new Error("Monaco editor DOM not found on page after 20s.");
  console.log("✅ Editor DOM found. Giving Monaco JS engine extra time to fully mount...");
  // Wait longer for Monaco's JS model to fully initialize after DOM appears
  await sleep(2500);

  // STEP 2: Language Switcher — ensure Python3 is selected
  try {
    console.log("🔍 Checking current language...");
    const knownLanguages = ["C++", "Java", "Python", "Python3", "C", "C#", "JavaScript", "TypeScript", "Go", "Rust"];
    const buttons = Array.from(document.querySelectorAll("button"));
    const langBtn = buttons.find(b => knownLanguages.includes(b.innerText.trim()));

    if (langBtn && langBtn.innerText.trim() !== "Python3") {
      console.log(`🔄 Switching from ${langBtn.innerText.trim()} to Python3...`);
      langBtn.click();
      await sleep(800); // wait for dropdown to appear

      // Query dropdown options AFTER dropdown is open
      const dropdownOptions = Array.from(document.querySelectorAll("li, div, span, [role='option']"));
      const pyOption = dropdownOptions.find(opt => opt.innerText.trim() === "Python3");

      if (pyOption) {
        pyOption.click();
        console.log("✅ Python3 selected.");
        // Wait for Monaco to re-initialize with the new language model
        await sleep(2500);
      } else {
        console.warn("⚠️ Python3 option not found in dropdown. Proceeding.");
        await sleep(800);
      }
    } else if (langBtn && langBtn.innerText.trim() === "Python3") {
      console.log("✅ Language is already Python3.");
    } else {
      console.log("⚠️ Language button not found by text. Proceeding with injection.");
    }
  } catch (e) {
    console.warn("⚠️ Language switcher error (proceeding anyway):", e);
  }

  // STEP 3: Inject Code into Monaco with VERIFICATION loop
  // This is the critical fix: we don't just call setValue, we verify the editor
  // actually holds our code before moving forward.
  console.log("💉 Starting code injection with verification...");
  let injectionVerified = false;

  for (let attempt = 0; attempt < 25; attempt++) {
    let editorInstance = null;

    if (window.monaco && window.monaco.editor) {
      // Method A: Get active editor instances
      const editors = window.monaco.editor.getEditors();
      if (editors.length > 0) {
        editorInstance = editors[0];
      }

      // Method B: Fallback to model if no editor instances found
      if (!editorInstance) {
        const models = window.monaco.editor.getModels();
        if (models.length > 0) {
          // Filter out test/console models, keep the main solution model
          const solutionModel = models.find(m =>
            !m.uri.path.toLowerCase().includes("test") &&
            !m.uri.path.toLowerCase().includes("console") &&
            !m.uri.path.toLowerCase().includes("testcase")
          ) || models[0];

          if (solutionModel) {
            // Set value on model and verify
            solutionModel.setValue(solutionCode);
            await sleep(600);
            const verifyValue = solutionModel.getValue();
            if (verifyValue.trim() === solutionCode.trim()) {
              console.log(`✅ Code VERIFIED in model on attempt ${attempt + 1}.`);
              injectionVerified = true;
              break;
            } else {
              console.warn(`⚠️ Model setValue attempt ${attempt + 1} - verification mismatch. Retrying...`);
            }
          }
        }
      }

      if (editorInstance) {
        // Set value via editor instance
        editorInstance.setValue(solutionCode);
        await sleep(600); // Let the model settle

        // CRITICAL VERIFICATION: Read back the current editor value
        const currentValue = editorInstance.getValue();
        if (currentValue.trim() === solutionCode.trim()) {
          console.log(`✅ Code VERIFIED in editor on attempt ${attempt + 1}.`);
          injectionVerified = true;
          break;
        } else {
          console.warn(`⚠️ Editor setValue attempt ${attempt + 1} - verification mismatch. Got ${currentValue.length} chars, expected ${solutionCode.length} chars. Retrying...`);
          // Focus the editor and try again
          editorInstance.focus();
          await sleep(400);
        }
      }
    } else {
      console.log(`⏳ Waiting for window.monaco (attempt ${attempt + 1}/25)...`);
    }

    await sleep(500);
  }

  if (!injectionVerified) {
    throw new Error("CRITICAL: Code injection could not be verified after 25 attempts. Monaco may not be ready or code mismatch persists.");
  }

  // STEP 4: Final settling wait — ensure React state has updated after monaco setValue
  console.log("⏳ Code verified. Settling for 1.5 seconds before submitting...");
  await sleep(1500);

  // STEP 5: Find and Click Submit Button
  console.log("🎯 Looking for Submit button...");
  let submitButton = null;
  for (let i = 0; i < 10; i++) {
    submitButton =
      document.querySelector("button[data-e2e-locator='console-submit-button']") ||
      Array.from(document.querySelectorAll("button")).find((b) =>
        b.innerText && b.innerText.trim().toLowerCase() === "submit"
      );
    if (submitButton) break;
    console.log(`⏳ Submit button not found yet, waiting... (${i + 1}/10)`);
    await sleep(600);
  }

  if (!submitButton) {
    throw new Error("Could not find the LeetCode Submit button after 6 seconds.");
  }

  console.log("✅ Clicking submit...");
  submitButton.scrollIntoView({ behavior: "smooth", block: "center" });
  await sleep(500); // Let the scroll settle before clicking
  submitButton.click();

  // STEP 6: Watch for Verdict (up to 60 seconds)
  console.log("⏳ Waiting for LeetCode verdict...");
  const startTime = Date.now();
  const VERDICT_STRINGS = ["Accepted", "Wrong Answer", "Runtime Error", "Time Limit Exceeded", "Memory Limit Exceeded", "Compile Error"];

  while (Date.now() - startTime < 60000) {
    // Primary locator (LeetCode's official data attribute)
    let resultHeader = document.querySelector("span[data-e2e-locator='submission-result']");

    // Fallback: scan all visible elements for known verdict strings
    if (!resultHeader) {
      resultHeader = Array.from(document.querySelectorAll("span, h3, div")).find(
        (el) => el.innerText && VERDICT_STRINGS.includes(el.innerText.trim())
      );
    }

    if (resultHeader) {
      const verdict = resultHeader.innerText.trim();
      await sleep(500); // Let the page fully populate the runtime/memory stats
      const pageText = document.body.innerText;
      const runtimeMatch = pageText.match(/(\d+\s*ms)/);
      const memoryMatch = pageText.match(/(\d+(?:\.\d+)?\s*MB)/);
      const details = (runtimeMatch ? runtimeMatch[1] : "N/A") + " | " + (memoryMatch ? memoryMatch[1] : "N/A");

      console.log(`🎉 Verdict: ${verdict} | ${details}`);
      return { verdict, details };
    }
    await sleep(1000);
  }

  return { verdict: "Submitted", details: "Timed out waiting for verdict. Check the LeetCode window." };
}