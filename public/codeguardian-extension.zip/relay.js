// relay.js
// Guard to prevent duplicate listeners if injected multiple times
if (!window.codeGuardianRelayInitialized) {
    window.codeGuardianRelayInitialized = true;

    window.addEventListener("message", (event) => {
        if (event.source !== window) return;

        if (event.data.type === "CODEGUARDIAN_PING") {
            window.postMessage({ type: "CODEGUARDIAN_PONG", pingId: event.data.pingId }, "*");
        }

        if (event.data.type === "SUBMIT_SOLUTION") {
            chrome.runtime.sendMessage(event.data, (response) => {
                if (chrome.runtime.lastError) {
                    console.error("Extension Routing Error:", chrome.runtime.lastError.message);
                    window.postMessage({ type: "CODEGUARDIAN_SUBMISSION_COMPLETE", error: true, details: chrome.runtime.lastError.message }, "*");
                    return;
                }
                window.postMessage({ type: "CODEGUARDIAN_SUBMISSION_COMPLETE", response }, "*");
            });
        }
    });
}